/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "gps_mc60_lib.h"
#include "gt06_lib.h"
#include "mc60_gsm.h"
#include "sms_mc60.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

char ip_server[100]="139.162.20.71";              //ip address of the server
char port_number_server[50]="6023";               //port of the server
char apn_sim[40]="airtelgprs.com";                //apn for sim
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
IWDG_HandleTypeDef hiwdg;

TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM4_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_IWDG_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/**********************global variables*********************/
int latitude;
int longitude;
extern char gps_active_void[100];
int number_of_sattelites;
char imei_no[20];
char login_packet[50];
char message_to_be_sent[100];
int len_login_pkt;
int len_location_pkt;
char location_packet[150];
int len_alarm_pkt;
char alarm_packet[150];
int len_heartbeat_pkt;
char heartbeat_packet[150];
 int hour;
 int minute;
 int seconds;
 int day;
 int month;
 int year;
  char course_status_byte_1;
 char course_status_byte_2;
 uint8_t speed;
  int mcc;
 int mnc;
 int lac;
 int cellid;
 int gsm_signal_strength;
 char imei_no_hex[10];
 int j=0;
bool receive_sms_flag=0; 
int new_line_increment=0;
char rx_list_messages[500];
int inverted_comma_increment;
uint8_t start_index;
uint8_t last_index;
uint8_t start_index_2;
uint8_t last_index_2;
int serial_no_location;
int serial_no_alarm;
int serial_no_heartbeat;
char received_sms[200];
int k=0;
bool location_flag=0;
bool alarm_flag=0;
bool heartbeat_flag=0;
char received_mobile_number[40];
char word1[50];
char word2[50];
char word3[50];
/******************************************/
/**
  * @brief  EXTI line detection callbacks.
  * @param  GPIO_Pin: Specifies the pins connected EXTI line
  * @retval None
  */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(GPIO_Pin);
  /* NOTE: This function Should not be modified, when the callback is needed,
           the HAL_GPIO_EXTI_Callback could be implemented in the user file
   */
	if(GPIO_Pin==GPIO_PIN_1)
	{
		receive_sms_flag=1;
	}
}
/**
  * @brief  Extract the message and number from the SMS
  * @param  Message and number
  * @retval None
  */
void extract_msg_number(char* message,char* number)
{
	list_messages(rx_list_messages);   //AT command to read the messages
	/*************************************************************************************/
			/*Part of the code to extaract message and mobile number  from full string*/
			rx_list_messages[0]=0x34;         // because 1st index is a junk value
			for(int j=0;j<strlen(rx_list_messages);j++)
			{
				if(rx_list_messages[j]==0x0D)    //check the new line hex value 
				{
					new_line_increment++;
					if(new_line_increment==3)
					{
						start_index=j;
					}
					if(new_line_increment==4)
					{
						last_index=j;
					}
				}
				if(rx_list_messages[j]==0x22)    //check the inverted comma hex value 
				{
					inverted_comma_increment++;
					if(inverted_comma_increment==5)
					{
						start_index_2=j;
					}
					if(inverted_comma_increment==6)
					{
						last_index_2=j;
					}
				}
			}
			memset(message,0,200);
			for(j=start_index+2;j<last_index;j++)
			{
				message[j-(start_index+2)]=rx_list_messages[j];
			}
			memset(number,0,40);
			for(k=start_index_2+1;k<last_index_2;k++)
			{
				number[k-(start_index_2+1)]=rx_list_messages[k];
			}
/******************************************************************************/
			HAL_Delay(200);
			new_line_increment=0;
			inverted_comma_increment=0;		
}
/**
  * @brief  update the variables with message that came from SMS 
  * @param  Input message, output message that is to be sent to sender
  * @retval None
  */
void update_values_trough_message(char*input, char*output)
{
	/*******************************************************
	splitting the message 
	*******************************************************/
	char *ptr1,*ptr2,*ptr3;	
	char delim[] = " ";
	char *ptr = strtok(input, delim);
    ptr1=ptr;
    ptr = strtok(NULL, delim);
    ptr2=ptr;
	ptr = strtok(NULL, delim);
    ptr3=ptr;
	strcpy(word1,ptr1);
	strcpy(word2,ptr2);
	strcpy(word3,ptr3);
	/******************************************/
	if(strcmp(word1,"SET")==0)     //if we want to set any parameters
	{
		if(strcmp(word2,"IP")==0)    //for IP
		{
			memset(ip_server,0,100);
			strcpy(ip_server,word3);
			sprintf(output,"IP %s DONE",ip_server);
		}
		else if(strcmp(word2,"PORT")==0)   //for port
		{
			memset(port_number_server,0,50);
			strcpy(port_number_server,word3);
			sprintf(output,"PORT %s DONE",port_number_server);
		}
		else if(strcmp(word2,"APN")==0)  // for APN
		{
			memset(apn_sim,0,50);
			strcpy(apn_sim,word3);
			sprintf(output,"APN %s DONE",apn_sim);
		}
		else 
		{
			sprintf(output,"PLEASE CHECK YOUR MESSAGE");	 //if no valid message came from the user		
		}
	}
	else if(strcmp(word1,"QUERY")==0)     //to query any particular parameter
	{
		if(strcmp(word2,"IP")==0)          //for IP
		{
			sprintf(output,"IP = %s ",ip_server);
		}
		else if(strcmp(word2,"PORT")==0)   //for port
		{
			sprintf(output,"PORT = %s ",port_number_server);
		}
		else if(strcmp(word2,"APN")==0)    //for APN
		{
			sprintf(output,"APN = %s",apn_sim);
		}
		else if(strcmp(word2,"SIGNALSTRENGTH")==0) //for gsm signal strength
		{
			extract_gsm_signal_strength();
			sprintf(output,"GSM SIGNAL STRENGTH = %i",gsm_signal_strength);			
		}
		else 
		{
			sprintf(output,"PLEASE CHECK YOUR MESSAGE");			//if no valid message came
		}
	}
	else 
	{
		sprintf(output,"INVALID MESSAGE");			         //if no valid message came
	}
}
/**
  * @brief  Period elapsed callback in non blocking mode 
  * @param  htim : TIM handle
  * @retval None
  */
int timer_number;
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(htim);
  /* NOTE : This function Should not be modified, when the callback is needed,
            the __HAL_TIM_PeriodElapsedCallback could be implemented in the user file
   */
  if(htim->Instance==TIM4)
	{
		timer_number++;
		if((timer_number%40)==0)
		{
			location_flag=1;
		}
		if((timer_number%60)==0)
		{
			alarm_flag=1;
		}
		if((timer_number%15)==0)
		{
			heartbeat_flag=1;
		}
	}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  //MX_IWDG_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
	/**************************SET THE INITIAL PARAMETERS OF GSM*******************************/
	check_sim();                                   //checks if the status of the SIM
	HAL_Delay(200);
	set_apn(apn_sim);                              //Sets the APN of the SIM
	HAL_Delay(200);
	conect_gprs();                                 //connect with the network
	delete_all_messages();                         //delete all the messages in the SIM
	HAL_Delay(200);
  new_msg_indication();                          // for new message indication
	HAL_Delay(200);
  set_sms_text_mode();                           //to configure SMS in Text mode 
	HAL_Delay(200);
	set_character_set_to_gsm();                    //Set sms in GSM mode
  set_gnss_on();                                 //set on GNSS
	get_rmc_gnss_information();                    //query RMC information
  while(strcmp(gps_active_void,"A")!=0)          //to check if GNSS is on
  {
	  set_gnss_on();
	  get_rmc_gnss_information();
	  HAL_Delay(500);
  }
  HAL_Delay(200);
	closeTCP();                                    //close the tcp connection (if any)
	start_tcp(ip_server,port_number_server);       //start TCP/IP connection
	/***********************LOGIN PACKET*****************************/
	read_imei_no(imei_no);                         //read IMEI number
	len_login_pkt=login( login_packet, imei_no_hex); //make login packet
	send_packet_over_tcp(len_login_pkt);             //AT command to send login packet
	HAL_Delay(200);
	send_packet_through_tcp(len_login_pkt,login_packet);  //send login packet   
	HAL_Delay(200);
	/****************************************************************/
__HAL_TIM_CLEAR_IT(&htim4,TIM_IT_UPDATE);      //clearing the update flag in timer
	HAL_TIM_Base_Start_IT(&htim4);                                 //starting timer
  /******************************************************************************/
	/* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		/***********************IF SMS CAME*****************************/
		if(receive_sms_flag==1)                    //check any message came from SMS
		{
			receive_sms_flag=0;                      //resetting the flag
			extract_msg_number( received_sms, received_mobile_number);   //extract message and number
			update_values_trough_message(received_sms,message_to_be_sent); //updating the values and make the string to be sent to sender
			send_msg(received_mobile_number,message_to_be_sent);   //send the reply message to the sender
			memset(message_to_be_sent,0,100);		                  //clearing the buffer	
		}
		/***********************LOCATION PACKET*****************************/
		if(location_flag==1)                       //set by the timer  
		{
		  location_flag=0;                         //resetting the flag
			serial_no_location++;                    //increment the serial number of the packet
			read_date_time();                        //check Date and time
		  get_gga_gnss_information();              //get the GGA information
      get_vtg_gnss_information();              //get the VTG information
			extract_mcc_mnc_cellid_lac();            //extract MCC,MNC,Cellid and LAC
			len_location_pkt=location(location_packet,hour,minute,seconds,day,month,year,speed,number_of_sattelites,latitude,longitude,course_status_byte_1,course_status_byte_2,mcc,mnc,lac,cellid,serial_no_location);    //making of location packet
		  send_packet_over_tcp(len_location_pkt);  //AT command to send the packet
	    HAL_Delay(200); 
	    send_packet_through_tcp(len_location_pkt,location_packet);  //send the packet
	    HAL_Delay(200);
			memset(location_packet,0,150);           //clearing the buffer
		}
		/***********************ALARM PACKET*****************************/
		if(alarm_flag==1)                        //set by the timer
		{
		  alarm_flag=0;                         //resetting the flag
			serial_no_alarm++;                    //increment the serial number for alarm packet
			read_date_time();                     //read date and time
		  get_gga_gnss_information();           //get the GGA information
      get_vtg_gnss_information();           //get the VTG information
			extract_mcc_mnc_cellid_lac();         //extract MCC,MNC,Cellid and LAC
			extract_gsm_signal_strength();        //check GSM Signal Strength
			len_alarm_pkt=alarm(alarm_packet,hour,minute,seconds,day,month,year,speed,number_of_sattelites,latitude,longitude,course_status_byte_1,course_status_byte_2,mcc,mnc,lac,cellid,gsm_signal_strength,serial_no_alarm);  //make alarm packet
		  send_packet_over_tcp(len_alarm_pkt);      //AT cammand to send packet
	    HAL_Delay(200);
	    send_packet_through_tcp(len_alarm_pkt,alarm_packet);  //semd the alarm packet
	    HAL_Delay(200);
			memset(alarm_packet,0,150);           //clearing the buffer
		}
		/***********************HEARTBEAT PACKET*****************************/
		if(heartbeat_flag==1)                   //flag set by the timer
		{
		  heartbeat_flag=0;                     //resetting the flag
			serial_no_heartbeat++;                //increment the serial number for heartbeat packet
			extract_gsm_signal_strength();        //check GSM Signal Strength
			len_heartbeat_pkt=heartbeat(heartbeat_packet,gsm_signal_strength,serial_no_alarm);   //make packet for heartbeat
			send_packet_over_tcp(len_heartbeat_pkt); //AT cammand to send packet
	    HAL_Delay(200);
	    send_packet_through_tcp(len_heartbeat_pkt,heartbeat_packet); //semd the heartbeat packet
	    HAL_Delay(200);
			memset(alarm_packet,0,150);            //clearing the buffer
		}
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL8;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief IWDG Initialization Function
  * @param None
  * @retval None
  */
static void MX_IWDG_Init(void)
{

  /* USER CODE BEGIN IWDG_Init 0 */

  /* USER CODE END IWDG_Init 0 */

  /* USER CODE BEGIN IWDG_Init 1 */

  /* USER CODE END IWDG_Init 1 */
  hiwdg.Instance = IWDG;
  hiwdg.Init.Prescaler = IWDG_PRESCALER_32;
  hiwdg.Init.Reload = 4095;
  if (HAL_IWDG_Init(&hiwdg) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN IWDG_Init 2 */

  /* USER CODE END IWDG_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 0;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 32000;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 1000;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin : PB1 */
  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
