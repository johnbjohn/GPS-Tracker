#ifndef __GPS_MC60_LIB_H
#define __GPS_MC60_LIB_H

#include "string.h"
#include "stdbool.h"
#include "stm32f1xx_hal.h"


void read_imei_no(char* imei_number);       //READ IMEI Number
void read_date_time(void);                  //READ Date and time from the module
void set_gnss_on(void);                     //To make GNSS ON
void get_rmc_gnss_information(void);        //To extract RMC information
void get_gga_gnss_information(void);        // To extract GGA information
void get_vtg_gnss_information(void);        //Extract VTG information
void extract_mcc_mnc_cellid_lac(void);      //Extract MCC MNC LAC and Cell ID
void extract_gsm_signal_strength(void);     //GET the GSM Signal Strength
/*************variables that are needed by any  GPS protocol*********/
extern int latitude;
extern int longitude;
extern int hour;
extern int minute;
extern int seconds;
extern int day;
extern int month;
extern int year;
extern int number_of_sattelites;
extern char course_status_byte_1;
extern char course_status_byte_2;
extern uint8_t speed;
extern int mcc;
extern int mnc;
extern int lac;
extern int cellid;
extern int gsm_signal_strength;
extern char imei_no_hex[10];
/**********************************************************/
extern UART_HandleTypeDef huart1;


#endif
