#ifndef __GT06_LIB_H
#define __GT06_LIB_H

#include "stm32f1xx_hal.h"
#include "string.h"
#include "stdbool.h"

int location(char* location_packet,int hour,int minute,int second,int day,int month,int year,int speed,int no_of_sattelites,int lattitude,int longitude,int course_1,int course_2,int mcc,int mnc,int lac,int cell_id,int serial_no);  //To make the location packet
int login(char* login_packet,char* imei_no);   //To make the login packet
int alarm(char* alarm_packet,int hour,int minute,int second,int day,int month,int year,int speed,int no_of_sattelites,int lattitude,int longitude,int course_1,int course_2,int mcc,int mnc,int lac,int cell_id,int gsm_signal_strength,int serial_no);  //To Make the alarm packet
int heartbeat(char* heartbeat_packet,int gsm_signal_strength,int serial_no);    //To Make the heartbeat packet
uint16_t crcx25(const uint8_t *data, size_t len);    //to get the CRC



#endif
