#include "gt06_lib.h"
/*************global variable***********/
char data_for_crc[200];
int length_of_crc_data;
uint16_t crc;
/**************************************/
/**
  * @brief  To Make the location packet
  * @param  all the parameters
  * @retval length of the packet
  */
int location(char* location_packet,int hour,int minute,int second,int day,int month,int year,int speed,int no_of_sattelites,int lattitude,int longitude,int course_1,int course_2,int mcc,int mnc,int lac,int cell_id,int serial_no)
{
	int j=0;
	int len_of_location_pkt=0;
	location_packet[len_of_location_pkt]=0x78;       //start byte
	location_packet[++len_of_location_pkt]=0x78;     //start byte
	++len_of_location_pkt;
	location_packet[++len_of_location_pkt]=0x12;     //protocol number
	location_packet[++len_of_location_pkt]=year;     //year
	location_packet[++len_of_location_pkt]=month;    //month
	location_packet[++len_of_location_pkt]=day;      //day
	location_packet[++len_of_location_pkt]=hour;     //hour
	location_packet[++len_of_location_pkt]=minute;   //minute
	location_packet[++len_of_location_pkt]=second;   //second
	location_packet[++len_of_location_pkt]=0xC0 | no_of_sattelites;  //no of sattelites
	location_packet[++len_of_location_pkt]=lattitude>>24; //lattitide(4th byte)
	location_packet[++len_of_location_pkt]=lattitude>>16; //lattitide(3th byte)
	location_packet[++len_of_location_pkt]=lattitude>>8;  //lattitide(2th byte)
	location_packet[++len_of_location_pkt]=lattitude;     //lattitide(1th byte)
	location_packet[++len_of_location_pkt]=longitude>>24;  //longitude(4th byte)
	location_packet[++len_of_location_pkt]=longitude>>16;  //longitude(3th byte)
	location_packet[++len_of_location_pkt]=longitude>>8;  //longitude(2th byte)
	location_packet[++len_of_location_pkt]=longitude;     //longitude(1th byte)
	location_packet[++len_of_location_pkt]=speed;         //speed
	location_packet[++len_of_location_pkt]=course_2;      //course byte 2
	location_packet[++len_of_location_pkt]=course_1;      //course byte 1
	location_packet[++len_of_location_pkt]=mcc>>8;        //mcc(2nd byte)
	location_packet[++len_of_location_pkt]=mcc;           //mcc(1st byte)
	location_packet[++len_of_location_pkt]=mnc;           //mnc
	location_packet[++len_of_location_pkt]=lac>>8;        //lac(byte 2)
	location_packet[++len_of_location_pkt]=lac;           //lac(byte 1)
	location_packet[++len_of_location_pkt]=cell_id>>16;   //cellID(byte 3)
	location_packet[++len_of_location_pkt]=cell_id>>8;   //cellID(byte 2)
	location_packet[++len_of_location_pkt]=cell_id;   //cellID(byte 1)
	/***********serial number*******************/
	if(serial_no>255)
	{
		location_packet[++len_of_location_pkt]=serial_no-255;
	  location_packet[++len_of_location_pkt]=0xFF;
	}
	else if(serial_no<=255)
	{
		location_packet[++len_of_location_pkt]=0x00;
	  location_packet[++len_of_location_pkt]=serial_no;
	}
	/******************************************/
	  location_packet[2]=len_of_location_pkt;
		for(j=2;j<len_of_location_pkt;j++)
	  {
			data_for_crc[j-2]=location_packet[j];
			++length_of_crc_data;
	  }
	crc=crcx25((uint8_t*)data_for_crc,length_of_crc_data);
	location_packet[++len_of_location_pkt]=crc>>8;   //crc byte 2
	location_packet[++len_of_location_pkt]=crc;      //crc byte 1
	location_packet[++len_of_location_pkt]=0x0D;     //stop byte
	location_packet[++len_of_location_pkt]=0x0A;     //stop byte
	crc=0;
	length_of_crc_data=0;
	memset(data_for_crc,0,200);        //clearing the buffer
	return len_of_location_pkt;
}
/**
  * @brief  To Make the login packet
  * @param  imei number and packet
  * @retval length of the packet
  */
int login(char* login_packet,char* imei_no)
{
	int j=0;
	int len_of_login_pkt=0;
	login_packet[len_of_login_pkt]=0x78;            //start byte
	login_packet[++len_of_login_pkt]=0x78;          //start byte
	++len_of_login_pkt;
	login_packet[++len_of_login_pkt]=0x01;          //protocol number
	for(j=0;j<strlen(imei_no);j++)
	{
		login_packet[++len_of_login_pkt]=imei_no[j];  //imei number
	}
	login_packet[++len_of_login_pkt]=0x00;         //serial number byte 2
	login_packet[++len_of_login_pkt]=0x01;         //serial number byte 1
	login_packet[2]=len_of_login_pkt;              //lenth
	for(j=2;j<len_of_login_pkt;j++)
	{
		data_for_crc[j-2]=login_packet[j];
		++length_of_crc_data;
	}
	crc=crcx25((uint8_t*)data_for_crc,length_of_crc_data);
	login_packet[++len_of_login_pkt]=crc>>8;       //crc byte 2
	login_packet[++len_of_login_pkt]=crc;          //crc byte 1
	login_packet[++len_of_login_pkt]=0x0D;         //stop byte 
	login_packet[++len_of_login_pkt]=0x0A;         //stop byte
	crc=0;
	length_of_crc_data=0;
	memset(data_for_crc,0,200);                    //clearing the buffer
	return len_of_login_pkt;
	
	
}
/**
  * @brief  To Make the alarm packet
  * @param  all the parameters
  * @retval length of the packet
  */
int alarm(char* alarm_packet,int hour,int minute,int second,int day,int month,int year,int speed,int no_of_sattelites,int lattitude,int longitude,int course_1,int course_2,int mcc,int mnc,int lac,int cell_id,int gsm_signal_strength,int serial_no)
{
	int j=0;
	int len_of_alarm_pkt=0;
	alarm_packet[len_of_alarm_pkt]=0x78;        //start byte
	alarm_packet[++len_of_alarm_pkt]=0x78;      //start byte
	++len_of_alarm_pkt;
	alarm_packet[++len_of_alarm_pkt]=0x16;      //protocol number
	alarm_packet[++len_of_alarm_pkt]=year;      //year
	alarm_packet[++len_of_alarm_pkt]=month;     //month
	alarm_packet[++len_of_alarm_pkt]=day;       //day
	alarm_packet[++len_of_alarm_pkt]=hour;      //hour
	alarm_packet[++len_of_alarm_pkt]=minute;    //minute
	alarm_packet[++len_of_alarm_pkt]=second;    //second
	alarm_packet[++len_of_alarm_pkt]=0xC0 | no_of_sattelites;  //number of sattelites
	alarm_packet[++len_of_alarm_pkt]=lattitude>>24;      //lattitide(4th byte) 
	alarm_packet[++len_of_alarm_pkt]=lattitude>>16;      //lattitide(3th byte)
	alarm_packet[++len_of_alarm_pkt]=lattitude>>8;       //lattitide(2th byte)
	alarm_packet[++len_of_alarm_pkt]=lattitude;          //lattitide(1th byte)
	alarm_packet[++len_of_alarm_pkt]=longitude>>24;      //longitude(4th byte)
	alarm_packet[++len_of_alarm_pkt]=longitude>>16;      //longitude(4th byte)
	alarm_packet[++len_of_alarm_pkt]=longitude>>8;       //longitude(4th byte)
	alarm_packet[++len_of_alarm_pkt]=longitude;          //longitude(4th byte)
	alarm_packet[++len_of_alarm_pkt]=speed;              //speed
	alarm_packet[++len_of_alarm_pkt]=course_2;           //course byte 2
	alarm_packet[++len_of_alarm_pkt]=course_1;           //course byte 1
	alarm_packet[++len_of_alarm_pkt]=mcc>>8;             //mcc byte 2
	alarm_packet[++len_of_alarm_pkt]=mcc;                //mcc byte 1
	alarm_packet[++len_of_alarm_pkt]=mnc;                //mnc
	alarm_packet[++len_of_alarm_pkt]=lac>>8;             //lac byte 2
	alarm_packet[++len_of_alarm_pkt]=lac;                //lac byte 1 
	alarm_packet[++len_of_alarm_pkt]=cell_id>>16;        //CellID byte 3
	alarm_packet[++len_of_alarm_pkt]=cell_id>>8;         //CellID byte 2
	alarm_packet[++len_of_alarm_pkt]=cell_id;            //cellID byte 1 
	alarm_packet[++len_of_alarm_pkt]=0 | 0<<1 | 1<<2 | 0<<3 | 0<<4 | 0<<5 | 1<<6 | 0<<7;   //terminal information content
	alarm_packet[++len_of_alarm_pkt]=0x04;               //volatage
	/*********************gsm signal strength********************/
	if(gsm_signal_strength>0)
	{
		alarm_packet[++len_of_alarm_pkt]=0x00;
	}
	else if(gsm_signal_strength>10)
	{
		alarm_packet[++len_of_alarm_pkt]=0x01;
	}
	else if(gsm_signal_strength>15)
	{
		alarm_packet[++len_of_alarm_pkt]=0x02;
	}
	else if(gsm_signal_strength>20)
	{
		alarm_packet[++len_of_alarm_pkt]=0x03;
	}
	else if(gsm_signal_strength>25)
	{
		alarm_packet[++len_of_alarm_pkt]=0x04;
	}
	/*******************************************/
	alarm_packet[++len_of_alarm_pkt]=0x00;   //alarm
	alarm_packet[++len_of_alarm_pkt]=0x01;   //language
	/*****************serial number***************/
	if(serial_no>255)
	{
		alarm_packet[++len_of_alarm_pkt]=serial_no-255;
	  alarm_packet[++len_of_alarm_pkt]=0xFF;
	}
	else if(serial_no<=255)
	{
		alarm_packet[++len_of_alarm_pkt]=0x00;
	  alarm_packet[++len_of_alarm_pkt]=serial_no;
	}
	/**********************************************/
	alarm_packet[2]=len_of_alarm_pkt;         //lenth of the packet
	for(j=2;j<len_of_alarm_pkt;j++)
	{
		data_for_crc[j-2]=alarm_packet[j];
		++length_of_crc_data;
	}
	crc=crcx25((uint8_t*)data_for_crc,length_of_crc_data);
	alarm_packet[++len_of_alarm_pkt]=crc>>8;   //crc byte 2
	alarm_packet[++len_of_alarm_pkt]=crc;      //crc byte 2
	alarm_packet[++len_of_alarm_pkt]=0x0D;     //stop byte
	alarm_packet[++len_of_alarm_pkt]=0x0A;     //stop byte
	crc=0;
	length_of_crc_data=0;
	memset(data_for_crc,0,200);                //clearing the buffer
	return len_of_alarm_pkt;
	
}
/**
  * @brief  To Make the heartbeat packet
  * @param  gsm signal strength, serial number and packet
  * @retval length of the packet
  */
int heartbeat(char* heartbeat_packet,int gsm_signal_strength,int serial_no)
{
	int j=0;
	int len_of_heartbeat_pkt=0;
	heartbeat_packet[len_of_heartbeat_pkt]=0x78;           //start byte
	heartbeat_packet[++len_of_heartbeat_pkt]=0x78;         //start byte
	++len_of_heartbeat_pkt;
	heartbeat_packet[++len_of_heartbeat_pkt]=0x13;         //protocol number
	heartbeat_packet[++len_of_heartbeat_pkt]=0 | 0<<1 | 1<<2 | 0<<3 | 0<<4 | 0<<5 | 1<<6 | 0<<7;  //terminal information content
	heartbeat_packet[++len_of_heartbeat_pkt]=0x04;        //voltage level
	/****************gsm signal strength*********************/
	if(gsm_signal_strength>0)
	{
		heartbeat_packet[++len_of_heartbeat_pkt]=0x00;
	}
	else if(gsm_signal_strength>10)
	{
		heartbeat_packet[++len_of_heartbeat_pkt]=0x01;
	}
	else if(gsm_signal_strength>15)
	{
		heartbeat_packet[++len_of_heartbeat_pkt]=0x02;
	}
	else if(gsm_signal_strength>20)
	{
		heartbeat_packet[++len_of_heartbeat_pkt]=0x03;
	}
	else if(gsm_signal_strength>25)
	{
		heartbeat_packet[++len_of_heartbeat_pkt]=0x04;
	}
	/***********************************************/
	heartbeat_packet[++len_of_heartbeat_pkt]=0x00;  //alarm(now no alarm)
	heartbeat_packet[++len_of_heartbeat_pkt]=0x01;  //language-english
	/*************serial number*********************/
	if(serial_no>255)
	{
		heartbeat_packet[++len_of_heartbeat_pkt]=serial_no-255;
	  heartbeat_packet[++len_of_heartbeat_pkt]=0xFF;
	}
	else if(serial_no<=255)
	{
		heartbeat_packet[++len_of_heartbeat_pkt]=0x00;
	  heartbeat_packet[++len_of_heartbeat_pkt]=serial_no;
	}
	/***********************************************/
	heartbeat_packet[2]=len_of_heartbeat_pkt;
	for(j=2;j<len_of_heartbeat_pkt;j++)
	{
		data_for_crc[j-2]=heartbeat_packet[j];
		++length_of_crc_data;
	}
	crc=crcx25((uint8_t*)data_for_crc,length_of_crc_data);
	heartbeat_packet[++len_of_heartbeat_pkt]=crc>>8;  //crc byte 2
	heartbeat_packet[++len_of_heartbeat_pkt]=crc;     //crc byte 1
	heartbeat_packet[++len_of_heartbeat_pkt]=0x0D;    //stop byte
	heartbeat_packet[++len_of_heartbeat_pkt]=0x0A;    //stop byte
	crc=0;
	length_of_crc_data=0;
	memset(data_for_crc,0,200);                      //clearing the buffer
	return len_of_heartbeat_pkt;
	
}
	/**
  * @brief  to get the CRC
  * @param  data and length
  * @retval CRC
  */
uint16_t crcx25(const uint8_t *data, size_t len)
 { 
  uint16_t crc = 0xFFFF; 
  int i; 
  if (len) do { 
    crc ^= *data++; 
    for (i=0; i<8; i++) { 
      if (crc & 1) crc = (crc >> 1) ^ 0x8408; 
      else crc >>= 1; 
    } 
  } while (--len); 
  return(~crc); 
}
	
	
